<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/vendor/autoload.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get form data
  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $date = $_POST['date'];
  $time = $_POST['time'];
  $people = $_POST['people'];
  $message = $_POST['message'];

  // Validate inputs (you can add more validation if required)
  if (empty($name) || empty($email) || empty($phone) || empty($date) || empty($time) || empty($people)) {
    echo "Please fill all the required fields.";
    exit;
  }

  // Create a new PHPMailer instance
  $mail = new PHPMailer(true);

  try {
    // Set mailer to use SMTP
    $mail->isSMTP();

    // SMTP configuration
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587;
    $mail->SMTPSecure = 'tls';
    $mail->SMTPAuth = true;
    $mail->Username = 'smazon07@gmail.com';
    $mail->Password = 'Samuelmazon';

    // Set sender and recipient
    $mail->setFrom('your-email@gmail.com', 'Your Name');
    $mail->addAddress('smazon07@gmail.com', 'Samyueru Masson');

    // Set email subject and body
    $mail->Subject = 'Table Booking Request';
    $mail->Body = "Name: $name\nEmail: $email\nPhone: $phone\nDate: $date\nTime: $time\nNumber of People: $people\nMessage: $message";

    // Send the email
    $mail->send();
    echo "success";
  } catch (Exception $e) {
    echo "Unable to send the email. Please try again later. Error: " . $mail->ErrorInfo;
  }
} else {
  echo "Invalid request method.";
}
?>