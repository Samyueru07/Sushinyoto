<?php

require_once __DIR__ . '/../assets/vendor/phpmailer/phpmailer/src/Exception.php';
require_once __DIR__ . '/../assets/vendor/phpmailer/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/../assets/vendor/phpmailer/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class PHP_Email_Form {
    public $to;
    public $from_name;
    public $from_email;
    public $subject;
    public $message;
    public $mail;

    public function __construct() {
        $this->mail = new PHPMailer(true);
        $this->mail->isSMTP();
        $this->mail->SMTPAuth = true;
        $this->mail->SMTPSecure = 'tls';
        $this->mail->Host = 'smtp.gmail.com'; // Update with your SMTP server
        $this->mail->Port = 587; // Update with the SMTP port
        $this->mail->Username = 'your-email@gmail.com'; // Update with your email address
        $this->mail->Password = 'your-password'; // Update with your email password
        $this->mail->setFrom('your-email@gmail.com', 'Your Name'); // Update with your email and name
    }

    public function add_message($content, $label = '') {
        $this->message .= "<p><strong>{$label}:</strong> {$content}</p>";
    }

    public function send() {
        $this->mail->addAddress($this->to);
        $this->mail->Subject = $this->subject;
        $this->mail->Body = $this->message;

        try {
            $this->mail->send();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}

$receiving_email_address = 'contact@example.com';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $php_email_form = '../assets/vendor/php-email-form/php-email-form.php';
    if (file_exists($php_email_form)) {
        require_once $php_email_form;

        $contact = new PHP_Email_Form();
        $contact->to = $receiving_email_address;
        $contact->from_name = $_POST['name'];
        $contact->from_email = $_POST['email'];
        $contact->subject = $_POST['subject'];

        $contact->add_message($_POST['name'], 'From');
        $contact->add_message($_POST['email'], 'Email');
        $contact->add_message($_POST['message'], 'Message', 10);

        if ($contact->send()) {
            echo 'success';
        } else {
            echo 'Unable to send the email. Please try again later.';
        }
    } else {
        die('Unable to load the "PHP Email Form" library!');
    }
} else {
    echo 'Invalid request method.';
}
?>