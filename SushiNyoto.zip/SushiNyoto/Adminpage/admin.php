<?php
// Check if the form is submitted and the action parameter is set
if (isset($_POST['action'])) {
  $action = $_POST['action'];

  // Handle add_category action
  if ($action === 'add_category') {
    if (isset($_POST['name'])) {
      $categoryName = $_POST['name'];
      // Add your logic here to store the category name in your preferred manner
      // For example, you can save it to a database or a file
      // You can also perform additional validation or sanitization of the input data
      // Return an appropriate response or success message if needed
    }
  }

  // Handle add_item action
  elseif ($action === 'add_item') {
    if (isset($_POST['category'], $_POST['name'], $_POST['price'], $_POST['ingredients'])) {
      $category = $_POST['category'];
      $itemName = $_POST['name'];
      $itemPrice = $_POST['price'];
      $itemIngredients = $_POST['ingredients'];
      // Add your logic here to store the item details in your preferred manner
      // For example, you can save them to a database or a file
      // You can also perform additional validation or sanitization of the input data
      // Return an appropriate response or success message if needed
    }
  }

  // Handle other actions if needed

  else {
    // Invalid action parameter
    // Return an appropriate error message or response
  }
}
?>
